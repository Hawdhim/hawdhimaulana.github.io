define({
  "_widgetLabel": "Controller intestazione",
  "signin": "Accedi",
  "signout": "Disconnetti",
  "about": "Informazioni",
  "signInTo": "Accedi a",
  "cantSignOutTip": "Questa funzione non è disponibile in modalità anteprima.",
  "more": "altro"
});