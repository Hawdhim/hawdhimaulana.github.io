define({
  "_widgetLabel": "Controller antet",
  "signin": "Conectare",
  "signout": "Deconectare",
  "about": "Despre",
  "signInTo": "Autentificare la",
  "cantSignOutTip": "Această funcţie nu este disponibilă în modul de previzualizare.",
  "more": "mai mult"
});